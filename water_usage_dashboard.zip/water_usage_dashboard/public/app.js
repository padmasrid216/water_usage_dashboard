const form = document.getElementById("usageForm");
const message = document.getElementById("formMessage");
const body = document.getElementById("recordsBody");
let chart;

const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
document.getElementById("date").value = localDate;
document.getElementById("todayLabel").textContent = today.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });

async function api(url, options = {}) {
  const response = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Something went wrong.");
  return result;
}
function liters(n) { return Number(n).toLocaleString(undefined, { maximumFractionDigits: 1 }); }

async function loadDashboard() {
  try {
    const [rows, summary] = await Promise.all([api("/api/usage"), api("/api/summary")]);
    document.getElementById("totalUsage").innerHTML = `${liters(summary.total)} <small>L</small>`;
    document.getElementById("todayUsage").innerHTML = `${liters(summary.todayTotal)} <small>L</small>`;
    document.getElementById("recordCount").textContent = summary.records;
    document.getElementById("topArea").textContent = summary.topArea;
    document.getElementById("topAreaAmount").textContent = summary.records ? `${liters(summary.topAreaLiters)} liters recorded` : "Add a record to see insights";
    renderRows(rows);
    renderChart(rows);
  } catch (error) {
    body.innerHTML = `<tr><td colspan="5" class="empty-row">Could not connect to the backend. Start the server with npm start.</td></tr>`;
  }
}
function renderRows(rows) {
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty-row">No records yet. Add your first usage entry above.</td></tr>';
    return;
  }
  body.innerHTML = rows.slice(0, 12).map(row => `
    <tr>
      <td>${escapeHtml(row.date)}</td>
      <td><span class="area-tag">${escapeHtml(row.area)}</span></td>
      <td>${escapeHtml(row.note || "—")}</td>
      <td class="liters">${liters(row.liters)} L</td>
      <td><button class="delete-btn" data-id="${escapeHtml(row.id)}">Delete</button></td>
    </tr>`).join("");
}
function renderChart(rows) {
  const totals = {};
  rows.forEach(row => totals[row.area] = (totals[row.area] || 0) + Number(row.liters));
  const labels = Object.keys(totals);
  document.getElementById("emptyChart").style.display = labels.length ? "none" : "flex";
  if (chart) chart.destroy();
  if (!window.Chart || !labels.length) return;
  chart = new Chart(document.getElementById("usageChart"), {
    type: "bar",
    data: { labels, datasets: [{ label: "Liters used", data: labels.map(label => totals[label]), backgroundColor: ["#2683d8", "#f6c64a", "#35b78b", "#a48be7", "#f18d76", "#7bbbd8"], borderRadius: 7, maxBarThickness: 48 }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false }, ticks: { color: "#7b8797", font: { size: 10 } } }, y: { beginAtZero: true, grid: { color: "#eef1f5" }, ticks: { color: "#7b8797", font: { size: 10 } } } } }
  });
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  message.textContent = "Saving…";
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    await api("/api/usage", { method: "POST", body: JSON.stringify(payload) });
    message.textContent = "Record saved successfully!";
    form.reset();
    document.getElementById("date").value = localDate;
    await loadDashboard();
  } catch (error) {
    message.textContent = error.message;
  }
});
body.addEventListener("click", async event => {
  const button = event.target.closest("[data-id]");
  if (!button) return;
  if (!confirm("Delete this usage record?")) return;
  try { await api(`/api/usage/${encodeURIComponent(button.dataset.id)}`, { method: "DELETE" }); await loadDashboard(); }
  catch (error) { alert(error.message); }
});
document.getElementById("refreshBtn").addEventListener("click", loadDashboard);
loadDashboard();