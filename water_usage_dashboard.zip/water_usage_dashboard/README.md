# WaterWise — Water Usage Dashboard

A beginner-friendly full-stack project built with HTML, CSS, JavaScript, Node.js, and Express. Records are stored in a local JSON file.

## Features
- Dashboard cards for total usage, today's usage, record count, and highest-use area
- Add water usage records with date, area, liters, and an optional note
- Chart comparing usage by area
- Recent records table with delete and refresh actions
- Backend API with input validation
- Responsive layout for desktop and mobile

## Requirements
- Node.js (LTS recommended)
- Internet connection on first page load for the Chart.js CDN (the dashboard still works without the chart library, but the chart will not display)

## How to run in VS Code
1. Extract `water_usage_dashboard.zip`.
2. Open the extracted `water_usage_dashboard` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run `npm install` once.
5. Run `npm start`.
6. Open `http://localhost:3000` in your browser.

Do not open `public/index.html` directly as a file; open it through the local server so the API works.

## API endpoints
- `GET /api/usage` — list records
- `POST /api/usage` — add a record (`date`, `area`, `liters`, optional `note`)
- `DELETE /api/usage/:id` — delete a record
- `GET /api/summary` — dashboard summary

## Project explanation
- **Frontend:** `public/index.html`, `public/style.css`, `public/app.js`
- **Backend:** `server.js` using Express
- **Storage:** `data/water_data.json`
- **Chart:** Chart.js bar chart grouped by usage area

This is a student project/demo. The data is stored locally and is not a production-grade multi-user database.
