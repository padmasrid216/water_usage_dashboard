const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "water_data.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function readData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch (error) {
    return [];
  }
}
function saveData(rows) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(rows, null, 2));
}

app.get("/api/usage", (req, res) => {
  res.json(readData().sort((a, b) => b.date.localeCompare(a.date)));
});

app.post("/api/usage", (req, res) => {
  const { date, area, liters, note = "" } = req.body;
  const amount = Number(liters);
  if (!date || !area || !Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ error: "Enter a date, area, and positive water usage in liters." });
  }
  const rows = readData();
  const record = {
    id: Date.now().toString(),
    date: String(date),
    area: String(area).trim().slice(0, 80),
    liters: amount,
    note: String(note).trim().slice(0, 200)
  };
  rows.push(record);
  saveData(rows);
  res.status(201).json(record);
});

app.delete("/api/usage/:id", (req, res) => {
  const rows = readData();
  const updated = rows.filter(row => row.id !== req.params.id);
  if (updated.length === rows.length) return res.status(404).json({ error: "Record not found." });
  saveData(updated);
  res.json({ success: true });
});

app.get("/api/summary", (req, res) => {
  const rows = readData();
  const total = rows.reduce((sum, row) => sum + Number(row.liters || 0), 0);
  const today = new Date().toISOString().slice(0, 10);
  const todayTotal = rows.filter(row => row.date === today).reduce((sum, row) => sum + Number(row.liters || 0), 0);
  const areas = {};
  rows.forEach(row => areas[row.area] = (areas[row.area] || 0) + Number(row.liters || 0));
  const topArea = Object.entries(areas).sort((a, b) => b[1] - a[1])[0];
  res.json({ total, todayTotal, records: rows.length, topArea: topArea ? topArea[0] : "—", topAreaLiters: topArea ? topArea[1] : 0 });
});

app.listen(PORT, () => console.log(`Water Usage Dashboard running at http://localhost:${PORT}`));